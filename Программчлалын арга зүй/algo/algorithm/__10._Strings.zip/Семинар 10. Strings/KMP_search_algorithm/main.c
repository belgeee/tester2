#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char s[20], t[50];
	int i,j,n,m,k;
	int f[20];
	printf("Enter string:"); scanf("%s",t);
	printf("Enter pattern:"); scanf("%s",s);
	n=strlen(t);
	m=strlen(s);
	j=0; f[1]=0;
	for(k=2;k<=m;k++)
	{
		while((s[j]!=s[k-1]) && (j>0))
		j=f[j]; if(s[j]==s[k-1]) j= j+1;
		f[k]=j;
	}
	j=0;
	for(i=0;i<n;i++)
	{
		while((s[j]!=t[i]) && (j>0)) j=f[j];
		if(s[j]=t[i]) j=j+1;
		if(j==m){
			printf("bairlal:%d", i-m+1);
			j=f[j];
		}
	}
	scanf("%d", i);
	return 0;
}
